﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using _21._106_02_Autoservice.Models;
using System.Data.Entity;

namespace _21._106_02_Autoservice
{
    /// <summary>
    /// Логика взаимодействия для PersonalWindow.xaml
    /// </summary>
    public partial class PersonalWindow : Window
    {
        Entities db = Helper.GetContext();
        public PersonalWindow()
        {
            InitializeComponent();
            var querry = db.Staff;
            dtg_Staff.ItemsSource = querry.ToList();
        }
        public void Refresh()
        {
            InitializeComponent();
            var querry = db.Staff;
            dtg_Staff.ItemsSource = querry.ToList();
        }

        public void Create(Staff staff)
        {
            db.Staff.Add(staff);
            db.SaveChanges();
            Refresh();
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Staff newStaff = new Staff();
                newStaff.Name = tb_Name.Text.ToString();
                newStaff.Surname = tb_Surname.Text.ToString();
                newStaff.Patronymic = tb_Patronymic.Text.ToString();
                newStaff.IdRole = int.Parse(tb_IdRole.Text);
                newStaff.Experience = int.Parse(tb_Experience.Text);
                DateTime DateOfBirth = DateTime.Parse(tb_DateOfBirth.Text.ToString());
                newStaff.DateOfBirth = DateOfBirth;
                newStaff.PassportData = int.Parse(tb_PassportData.Text);
                newStaff.Adress = tb_Adress.Text.ToString();
                Create(newStaff);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Данные введены некорректно!", ex.Message);
            }
        }

        private void btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            Staff selectedItem = dtg_Staff.SelectedItem as Staff;

            if (selectedItem != null)
            {
                db.Entry(selectedItem).State = EntityState.Modified;

                if (MessageBox.Show("Вы действительно хотите сохранить изменения?",
                    "Редактирование",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    db.SaveChanges();
                    Refresh();
                }
                else
                {
                    Refresh();
                }
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            Staff selectedItem = dtg_Staff.SelectedItem as Staff;

            if (selectedItem != null)
            {
                DbSet<Staff> items = db.Staff;

                items.Remove(selectedItem);

                if (MessageBox.Show("Вы действительно хотите удалить?",
                    "Удаление",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    db.SaveChanges();
                    Refresh();
                }
                else
                {
                    Refresh();
                }
            }
        }
    }
}
