﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _21._106_02_Autoservice.Models;

namespace _21._106_02_Autoservice
{
    class Helper
    {
        private static Entities s_Entities;

        public static Entities GetContext()
        {
            if (s_Entities == null)
            {
                s_Entities = new Entities();
            }
            return s_Entities;
        }
    }
}
